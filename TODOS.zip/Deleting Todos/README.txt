# These are the project files for the project and section they are featured in

# Install the dependencies

npm install

# compile .ts files in Angular. Open another command line and go to the /client folder and run

npm run tsc -w

# Start the server from the root

node server

# Visit http://localhost:3000

