export class Todo{
    text: string;
    isCompleted: boolean;
}